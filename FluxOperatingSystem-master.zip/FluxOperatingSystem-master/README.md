# FluxOperatingSystem
A basic 32 bit UNIX alike operating system!
